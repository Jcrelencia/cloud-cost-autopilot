const { STSClient, AssumeRoleCommand } = require('@aws-sdk/client-sts');
const { EC2Client, DescribeInstancesCommand } = require('@aws-sdk/client-ec2');
const { CloudWatchClient, GetMetricStatisticsCommand } = require('@aws-sdk/client-cloudwatch');

/**
 * Assume an IAM role and get temporary credentials
 * @param {string} roleArn - The ARN of the IAM role to assume
 * @param {string} region - AWS region (default: us-east-1)
 * @returns {Object} Temporary credentials
 */
async function assumeRole(roleArn, region = 'us-east-1') {
  const stsClient = new STSClient({ region });
  
  const command = new AssumeRoleCommand({
    RoleArn: roleArn,
    RoleSessionName: 'CloudCostAutopilot-' + Date.now(),
    DurationSeconds: 3600, // 1 hour
  });

  try {
    console.log(`Attempting to assume role: ${roleArn}`);
    const response = await stsClient.send(command);
    
    console.log('✅ Successfully assumed role');
    return {
      accessKeyId: response.Credentials.AccessKeyId,
      secretAccessKey: response.Credentials.SecretAccessKey,
      sessionToken: response.Credentials.SessionToken,
      expiration: response.Credentials.Expiration,
    };
  } catch (error) {
    console.error('❌ Error assuming role:', error.message);
    throw new Error(`Failed to assume role: ${error.message}`);
  }
}

/**
 * List all EC2 instances in an AWS account
 * @param {Object} credentials - AWS temporary credentials from assumeRole
 * @param {string} region - AWS region (default: us-east-1)
 * @returns {Array} List of EC2 instances
 */
async function listEC2Instances(credentials, region = 'us-east-1') {
  const ec2Client = new EC2Client({
    region,
    credentials,
  });

  const command = new DescribeInstancesCommand({});
  
  try {
    console.log(`Fetching EC2 instances in region: ${region}`);
    const response = await ec2Client.send(command);
    const instances = [];
    
    // Parse the response
    response.Reservations?.forEach(reservation => {
      reservation.Instances?.forEach(instance => {
        // Extract name tag if it exists
        const nameTag = instance.Tags?.find(tag => tag.Key === 'Name');
        
        instances.push({
          instanceId: instance.InstanceId,
          instanceType: instance.InstanceType,
          state: instance.State.Name,
          launchTime: instance.LaunchTime,
          availabilityZone: instance.Placement?.AvailabilityZone,
          name: nameTag?.Value || 'Unnamed',
          tags: instance.Tags || [],
        });
      });
    });
    
    console.log(`✅ Found ${instances.length} EC2 instances`);
    return instances;
  } catch (error) {
    console.error('❌ Error listing EC2 instances:', error.message);
    throw new Error(`Failed to list EC2 instances: ${error.message}`);
  }
}

/**
 * Get CPU utilization metrics for an EC2 instance over the last 7 days
 * @param {Object} credentials - AWS temporary credentials from assumeRole
 * @param {string} instanceId - EC2 instance ID
 * @param {string} region - AWS region (default: us-east-1)
 * @returns {Object} CPU metrics including average
 */
async function getCPUUtilization(credentials, instanceId, region = 'us-east-1') {
  const cloudWatchClient = new CloudWatchClient({
    region,
    credentials,
  });

  const endTime = new Date();
  const startTime = new Date(endTime.getTime() - 7 * 24 * 60 * 60 * 1000); // 7 days ago

  const command = new GetMetricStatisticsCommand({
    Namespace: 'AWS/EC2',
    MetricName: 'CPUUtilization',
    Dimensions: [
      {
        Name: 'InstanceId',
        Value: instanceId,
      },
    ],
    StartTime: startTime,
    EndTime: endTime,
    Period: 86400, // 1 day in seconds (24 hours)
    Statistics: ['Average', 'Maximum'],
  });

  try {
    console.log(`Fetching CPU metrics for instance: ${instanceId}`);
    const response = await cloudWatchClient.send(command);
    
    // Calculate average CPU over all datapoints
    let avgCPU = 0;
    let maxCPU = 0;
    
    if (response.Datapoints && response.Datapoints.length > 0) {
      const totalAvg = response.Datapoints.reduce((sum, dp) => sum + (dp.Average || 0), 0);
      avgCPU = totalAvg / response.Datapoints.length;
      maxCPU = Math.max(...response.Datapoints.map(dp => dp.Maximum || 0));
    }

    console.log(`✅ CPU metrics - Avg: ${avgCPU.toFixed(2)}%, Max: ${maxCPU.toFixed(2)}%`);
    
    return {
      datapoints: response.Datapoints,
      averageCPU: avgCPU,
      maximumCPU: maxCPU,
      datapointCount: response.Datapoints.length,
    };
  } catch (error) {
    console.error(`❌ Error getting CPU metrics for ${instanceId}:`, error.message);
    throw new Error(`Failed to get CPU metrics: ${error.message}`);
  }
}

/**
 * Test AWS connection by attempting to assume role and list instances
 * @param {string} roleArn - IAM role ARN to test
 * @param {string} region - AWS region
 * @returns {Object} Connection test results
 */
async function testConnection(roleArn, region = 'us-east-1') {
  try {
    // Step 1: Assume role
    const credentials = await assumeRole(roleArn, region);
    
    // Step 2: Try to list EC2 instances
    const instances = await listEC2Instances(credentials, region);
    
    return {
      success: true,
      message: 'Connection successful',
      instanceCount: instances.length,
      credentialsExpire: credentials.expiration,
    };
  } catch (error) {
    return {
      success: false,
      message: error.message,
      error: error,
    };
  }
}

module.exports = {
  assumeRole,
  listEC2Instances,
  getCPUUtilization,
  testConnection,
};